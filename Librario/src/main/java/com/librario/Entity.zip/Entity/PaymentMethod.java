package com.librario.Entity;

public enum PaymentMethod {
    online,
    cash
}
