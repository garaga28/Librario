package com.librario.Entity;

public enum PaymentStatus {
    pending,
    completed,
    failed
}
