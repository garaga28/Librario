package com.librario.Entity;

public enum PaymentType {
    premium_membership,
    overdue_charges
}
